﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog2APART1
{

    internal class IngredientClass
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string UnitOfMeasurement { get; set; }

        public IngredientClass(string name, double quantity, string unitOfMeasurement)
        {
            Name = name;
            Quantity = quantity;
            UnitOfMeasurement = unitOfMeasurement;
        }

        // Method to scale the quantity of an ingredient by a given factor
        public void ScaleQuantity(double factor)
        {
            Quantity *= factor;
        }
    }
}