﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog2APART1
{
    class MainClass
    {
        private static readonly RecipeClass currentRecipe = new RecipeClass();

        private static void Main(string[] args)
        {
            bool running = true;
            while (running)
            {
                Console.WriteLine("\n***********************\nRecipe Application\n***********************\n");
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. Display the recipe");
                Console.WriteLine("3. Scale the recipe");
                Console.WriteLine("4. Modify ingredient quantity");
                Console.WriteLine("5. Delete an ingredient");
                Console.WriteLine("6. Search recipes by ingredient");
                Console.WriteLine("7. Clear recipe data");
                Console.WriteLine("8. Exit\n***********************");
                Console.Write("Select an option: ");

                try
                {
                    int option = int.Parse(Console.ReadLine());
                    if (option == 1)
                    {
                        EnterRecipe();
                    }
                    else if (option == 2)
                    {
                        DisplayRecipe();
                    }
                    else if (option == 3)
                    {
                        ScaleRecipe();
                    }
                    else if (option == 4)
                    {
                        ModifyIngredient();
                    }
                    else if (option == 5)
                    {
                        DeleteIngredient();
                    }
                    else if (option == 6)
                    {
                        SearchRecipes();
                    }
                    else if (option == 7)
                    {
                        ClearRecipe();
                    }
                    else if (option == 8)
                    {
                        running = false;
                    }
                    else
                    {
                        Console.WriteLine("\n***********************\nInvalid option. Please try again.");
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("\n***********************\nPlease enter a valid number.");
                }
            }
        }

        private static void EnterRecipe()
        {
            Console.Write("\n***********************\nEnter the number of ingredients: ");
            int numIngredients;
            if (int.TryParse(Console.ReadLine(), out numIngredients) && numIngredients > 0)
            {
                for (int i = 0; i < numIngredients; i++)
                {
                    Console.Write("\n***********************\nEnter ingredient name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter quantity: ");
                    double quantity;
                    if (double.TryParse(Console.ReadLine(), out quantity) && quantity > 0)
                    {
                        Console.Write("\n***********************\nEnter unit of measurement: ");
                        string unit = Console.ReadLine();

                        IngredientClass ingredient = new IngredientClass(name, quantity, unit);
                        currentRecipe.AddIngredient(ingredient);
                    }
                    else
                    {
                        Console.WriteLine("Invalid quantity. Please enter a valid positive number.");
                        i--; // Re-prompt for the same ingredient
                    }
                }

                Console.Write("\n***********************\nEnter the number of steps: ");
                int numSteps;
                if (int.TryParse(Console.ReadLine(), out numSteps) && numSteps > 0)
                {
                    for (int i = 0; i < numSteps; i++)
                    {
                        Console.Write($"\n***********************\nEnter step {i + 1}: ");
                        string step = Console.ReadLine();
                        currentRecipe.AddStep(step);
                    }
                }
                else
                {
                    Console.WriteLine("Invalid number of steps. Please enter a valid positive number.");
                }
            }
            else
            {
                Console.WriteLine("Invalid number of ingredients. Please enter a valid positive number.");
            }
        }

        private static void DisplayRecipe()
        {
            currentRecipe.DisplayRecipe();
        }

        private static void ScaleRecipe()
        {
            Console.Write("\n***********************\nEnter scale factor (0.5, 2, 3): ");
            double factor;
            if (double.TryParse(Console.ReadLine(), out factor) && factor > 0)
            {
                currentRecipe.ScaleRecipe(factor);
            }
            else
            {
                Console.WriteLine("Invalid scale factor. Please enter a valid positive number.");
            }
        }

        private static void ModifyIngredient()
        {
            Console.Write("\n***********************\nEnter ingredient name to modify: ");
            string name = Console.ReadLine();
            Console.Write("Enter new quantity: ");
            double newQuantity;
            if (double.TryParse(Console.ReadLine(), out newQuantity) && newQuantity > 0)
            {
                currentRecipe.ModifyIngredientQuantity(name, newQuantity);
            }
            else
            {
                Console.WriteLine("Invalid quantity. Please enter a valid positive number.");
            }
        }

        private static void DeleteIngredient()
        {
            Console.Write("\n***********************\nEnter ingredient name to delete: ");
            string name = Console.ReadLine();
            currentRecipe.DeleteIngredient(name);
        }

        private static void SearchRecipes()
        {
            Console.Write("\n***********************\nEnter ingredient name to search: ");
            string name = Console.ReadLine();
            var matchingRecipes = currentRecipe.SearchByIngredient(name);
            if (matchingRecipes.Count > 0)
            {
                Console.WriteLine("\nMatching recipes:");
                foreach (var recipe in matchingRecipes)
                {
                    Console.WriteLine(recipe);
                }
            }
            else
            {
                Console.WriteLine($"No recipes found containing '{name}'.");
            }
        }

        private static void ClearRecipe()
        {
            currentRecipe.ClearRecipe();
            Console.WriteLine("\nRecipe data cleared.");
        }
    }
}