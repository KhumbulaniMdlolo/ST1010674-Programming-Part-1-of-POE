﻿using System;
using System.Collections.Generic;

namespace prog2APART1
{
    internal class RecipeClass
    {
        public List<IngredientClass> Ingredients { get; } = new List<IngredientClass>();
        public List<string> Steps { get; } = new List<string>();

        // Method to add an ingredient to the recipe
        public void AddIngredient(IngredientClass ingredient)
        {
            Ingredients.Add(ingredient);
        }

        // Method to add a step to the recipe
        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        // Method to scale the recipe by a given factor
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.ScaleQuantity(factor);
            }
        }

        // Method to display the recipe
        public void DisplayRecipe()
        {
            if (Ingredients.Count == 0 && Steps.Count == 0)
            {
                Console.WriteLine("\nNo recipe data available. Please enter a recipe first.");
            }
            else
            {
                Console.WriteLine("\n***********************\nIngredients:");
                foreach (var ingredient in Ingredients)
                {
                    Console.WriteLine($"- {ingredient.Quantity} {ingredient.UnitOfMeasurement} {ingredient.Name}");
                }
                Console.WriteLine("\nSteps:");
                int stepNumber = 1;
                foreach (var step in Steps)
                {
                    Console.WriteLine($"{stepNumber++}. {step}");
                }
            }
        }

        // Method to clear the recipe data
        public void ClearRecipe()
        {
            Ingredients.Clear();
            Steps.Clear();
            Console.WriteLine("\nRecipe data cleared.");
        }

        // Method to modify the quantity of a specific ingredient
        public void ModifyIngredientQuantity(string ingredientName, double newQuantity)
        {
            var ingredient = Ingredients.Find(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase));
            if (ingredient != null)
            {
                ingredient.Quantity = newQuantity;
                Console.WriteLine($"Quantity of '{ingredientName}' modified successfully.");
            }
            else
            {
                Console.WriteLine($"Ingredient '{ingredientName}' not found.");
            }
        }

        // Method to delete a specific ingredient from the recipe
        public void DeleteIngredient(string ingredientName)
        {
            var ingredient = Ingredients.Find(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase));
            if (ingredient != null)
            {
                Ingredients.Remove(ingredient);
                Console.WriteLine($"Ingredient '{ingredientName}' deleted successfully.");
            }
            else
            {
                Console.WriteLine($"Ingredient '{ingredientName}' not found.");
            }
        }

        // Method to search recipes containing a specific ingredient
        public List<string> SearchByIngredient(string ingredientName)
        {
            var matchingRecipes = new List<string>();
            foreach (var ingredient in Ingredients)
            {
                if (ingredient.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))
                {
                    matchingRecipes.Add($"- {ingredient.Quantity} {ingredient.UnitOfMeasurement} {ingredient.Name}");
                }
            }
            return matchingRecipes;
        }
    }
}